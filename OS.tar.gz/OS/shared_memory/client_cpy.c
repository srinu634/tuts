#include<stdio.h>
#include<sys/shm.h>
#include "shared_mem.h"
#include<string.h>

extern int quit_flag;

int main() {  
char * shm_pntr;
char str[SIZE];
shm_pntr = shmat(KEY,NULL,0); //attach the server allocated segment

while(TRUE) {
printf("Enter a string\n");
gets(str);

if( strcmp(str,"quit") == )
{	smhdt(shm_pntr);
	exit(0);
}

sprintf(shm_pntr,str); //write the string to the shared memory region
sleep(1); //sleep for 1 sec

printf("Child process back to action\n");
}


return 0;
}
