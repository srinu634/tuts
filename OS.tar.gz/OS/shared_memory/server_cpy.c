/* Authored by Srinivas Suri (2011A7PS199H)
-> A server-Client program to illustrate shared memory concept 
-> Client waits until a string is inputted
-> Puts the string into the shared memory and sleeps for 1 second
-> Server checks if there is any string in the shared memory region
-> If it encounters a string, it prints it's length 
-> It then clears the whole memory segment,Sets the whole memory segment to 0
-> If it does not encounter any string in the shared segment,it sleeps for 0.5 sec and then checks again
-> type quit to exit
*/


#include<stdio.h>
#include<unistd.h>
#include<sys/shm.h>
#include "shared_mem.h"
#define BUFFERSIZE 1024

int seg_id;

int main() { 
char * shm_pntr; //pointer to shared memory from server side
int pid;   //To create a child process which acts as a client process
char str[SIZE];
 
seg_id = shmget(IPC_CREAT,BUFFERSIZE, 0666); //allocate memory_segment
shm_pntr = shmat ( seg_id,NULL,0);

memset(shm_pntr,0,BUFFERSIZE); //Clear the memory initially

while(TRUE) {
strcpy(str,shm_pntr); 

if(*str=='\0'){
	sleep(0.5);
	continue;
}

if( strcpy(str,"quit") == 0 ){ 
	shmdt(seg_id); //detach the segment from the program
//	shmclt(); // Mark the segment to be removed
	exit(0);  //exit the program
}

printf("Length of the string is: %d\n",strlen(str));
memset(shm_pntr,0,BUFFERSIZE); //Clear the segment memory
}

return 0;
} //end of :main
