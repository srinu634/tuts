#define SIZE 100 //string size
#define TRUE 1
#define FALSE 0
#define BUFFERSIZE 30
#define KEY 2234
