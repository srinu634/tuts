#include<stdio.h>
#include<unistd.h>
#include<sys/shm.h>
#include "shared_mem.h"
#include<string.h>


int main() {  
char * shm_pntr;
char str[SIZE];
int seg_id;

seg_id = shmget(KEY,BUFFERSIZE,IPC_CREAT | 0666); //Get the mem_seg by KEY from server
shm_pntr = shmat(seg_id,NULL,0); //attach the server allocated segment

while(TRUE) {
printf("Enter a string\n");
gets(str);


sprintf(shm_pntr,str); //write the string to the shared memory region
sleep(1); //sleep for 1 sec

if( strcmp(str,"quit") == 0 )
{	shmdt(shm_pntr); //Detach the segment from the process
	exit(0);
}

printf("Child process back to action\n");
}


return 0;
}
