/* Authored by Srinivas Suri (2011A7PS199H)
-> A server-Client program to illustrate shared memory concept 
-> Client waits until a string is inputted
-> Puts the string into the shared memory and sleeps for 1 second
-> Server checks if there is any string in the shared memory region
-> If it encounters a string, it prints it's length 
-> If it does not encounter any string in the shared segment,it sleeps for 0.5 sec and then checks again
-> type quit to exit
*/

#include<stdio.h>
#include<unistd.h>
#include<sys/shm.h>
#include "shared_mem.h"



int main() { 
char * shm_pntr; //pointer to shared memory from server side
char str[SIZE];
int seg_id;
 
seg_id = shmget(KEY,BUFFERSIZE,IPC_CREAT|0666 ); //allocate memory_segment 

shm_pntr = (char *)  shmat ( seg_id,NULL,0);

sprintf(shm_pntr,"");

while(TRUE) {
strcpy(str,shm_pntr); 

if(*str=='\0'){
	sleep(5);
	printf("Server back to action\n");
	continue;
}

if( strcmp(str,"quit") == 0 ){ 
	shmdt(seg_id); //detach the segment from the program
	shmctl (seg_id, IPC_RMID, 0); //Mark the segment to be removed //IPC_REMOVEID
	exit(0);  //exit the program
}

printf("Length of the string is: %d\n",strlen(str));

*shm_pntr = '\0';
}

return 0;
} //end of :main
