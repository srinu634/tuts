/*********** A Shell interpreter written in c*****/
/*By Srinivas suri (2011A7PS199H)
*	 Arkajyothi Batabyal (2011A7PS167H)
*	 Abhik De (2011C6PS569H) 
*/

#include <stdio.h>
#include<string.h>
#include<unistd.h>  //POSIX OS API.

/*****Defining all the global variables********/
#define true 1 
#define false 0 

char commandInput[1000]; //To store the command passed by the shell
char *Token; //To tokenize the command
char *commandTokenized[200];//To store the commands after they are tokenized.

/***** Defining the functions used************/
void execute_cd( );
void execute_mkdir( );
void execute_ls();
void execute_otherCommands();
void tokenize(); //To tokenize the linux command

/********Main Execution***********/
int main(void) {
	char temp[1000];
	while(true){
	printf("Enter a command$:- \n");
	gets(commandInput);
	Token = strtok(commandInput," "); //Tokenize the command by a space. ' '
	strcpy(temp,Token);
	tokenize();
	if( strcmp(temp,"cd") ==0 )
		execute_cd();
	else if (strcmp(temp,"mkdir")==0)	
		execute_mkdir();
	else if(strcmp(temp,"quit")==0)
		return (0); //To exit the shell
	else if(strcmp(temp,"ls")==0)
		execute_ls();
	else
		execute_otherCommands();
	}//end of while:true
	
	return 0;
}//end of main function

void execute_cd() {
int c;
c=chdir(commandTokenized[1]);
if(c==-1)
printf("Directory does not exist\n");

} //end of execute_cd

void execute_mkdir() {
int pid; //process_id
pid = fork();

if(pid) {
	wait(NULL); //wait till child process's execution is completed
}//Parent ID
else{
execv("/bin/mkdir",commandTokenized);
}//Child process

} //end of execute_mkdir

void execute_ls() {
int pid;
pid=fork(); //Create a Child process

if(pid==0)
execv("/bin/ls",commandTokenized);
else
wait(NULL); //wait till atleast one child's state is changed, in this case , there is only one child.

} //end of execute_ls

void execute_otherCommands(){
int pid;

char temp[1000];
temp[0]=NULL;
strcat(temp,"/bin/");
strcat(temp,commandTokenized[0]);

pid=fork();
if(pid==0)
	execv( temp,commandTokenized);
else
	wait(NULL);

}

void tokenize() {
int i=0;
for(i=0;i<200;i++)
	commandTokenized[i]=NULL;
i=0;
while(Token!=NULL){
commandTokenized[i] = malloc( sizeof(char)*( strlen(Token)+1));
strcpy(commandTokenized[i],Token);
i++;
Token  = strtok(NULL, " ");
}//end of while loop

}//end of tokenize

/*****   strtok()   Example*********/
/* while(Token!=NULL) { 
*	printf("%s\n",Token);
*	Token = strtok(NULL, " ");
*	}
*/
/********End of strtok() Example***********/
