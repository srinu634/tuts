#include<stdio.h>
#include<sys/shm.h>
#include<string.h>
#include "shared_data.h"
#include<fcntl.h> //File control constants
#include<stdlib.h>
#include<mqueue.h>
#define true 1

int main(){

int mqid,pid,nmbr;
struct message m1;
long datalength,typ1,type2;
char str[100],temp[100];

mqid = msgget( QUEUEKEY, IPC_CREAT | 0666 );   //Open the message Queue
printf("mqid = %d\n",mqid);
datalength = sizeof(m1) - sizeof(m1.type);


system("/bin/bash -c 'cc writer1.c'");   //Call writer1.c
system("/bin/bash -c './a.out'"); 

while(true){
msgrcv(mqid,&m1,datalength,0,0)  ;
if( m1.type==100){
printf("TYPE 1 Message received\n");
pid = fork( );
if( pid == 0 ){
   printf("Executing prog1.exe\n");
   execv("usr/bin/prog1.exe",NULL);
   exit(0);
}

}
else
if(m1.type==200){
   printf("TYPE2 Message Received\n");
   strcpy(str,"'./a.out ");
   sprintf(temp,"%d'",m1.nmbr);
   strcat(str,temp);
   
pid = fork( );
if ( pid == 0 ){
   char tempstr[200];
   strcpy(tempstr,"/bin/bash -c ");
   strcat(tempstr,str);   
   system("/bin/bash -c 'cc reader2.c'");  //Compile reader2.c
   system(tempstr);   //Execute ./a.out 
exit(0);
}

}



}






return 0;
} 
