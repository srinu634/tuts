#define MEMKEY 1234
#define QUEUEKEY 4321
#define SIZE 124
#define BUFFERSIZE 32
#define KEYTYPE 100

struct message {
int nmbr;
long type;
};

int getSegID () { 
return shmget(MEMKEY,SIZE,IPC_CREAT | 0666 );
//0666 -> Give read/write permissions to all the users
}

char * attachSHM(){
return shmat(getSegID(),NULL,0);
}


