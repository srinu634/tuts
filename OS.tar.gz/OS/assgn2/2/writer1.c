#include<stdio.h>
#include<sys/shm.h>
#include<stdlib.h>
#include<string.h>
#include "shared_data.h"
#include<fcntl.h> //File control constants
#include<mqueue.h>

int main( ) {

long datalength;
int memsegid,mqid,pid;
char *memseg_pntr,*memstart;
int nmbr;
static struct message m1;

printf("In writer1.c\n");
memsegid = shmget(MEMKEY,SIZE, IPC_CREAT | 0666); //Get the segment ,a function defined in shared_data.h 
memseg_pntr = attachSHM(); //Attach the shared memory to the virtual memory space, in shared_data.h
memstart = memseg_pntr;

sscanf(memseg_pntr,"%d",&nmbr); //Read the number from the SharedMemory
printf("Number scanned from shared memory is %d\n",nmbr);

//Create a message to send
m1.type = 100;
m1.nmbr = nmbr ;  //Setting message attributes

mqid = msgget(QUEUEKEY, IPC_CREAT | 0666 ); //Create the message queue
datalength = sizeof(m1) - sizeof( m1.type); 


msgsnd(mqid,&m1,datalength,0) ;
printf("Message sent, mqid = %d\n",mqid);
nmbr = nmbr + 1;

//rewind(memseg_pntr);
sprintf(memstart,"%d ",nmbr);
shmdt(memseg_pntr); //Detach the SharedMemory Segment
wait(400);
printf("writer1.c exiting\n");

system("/bin/bash -c 'cc writer2.c'");
system("/bin/bash -c './a.out'"); 
    //Call writer2.c


return (0);
}
