#include<stdio.h>
#include<unistd.h>
#include<sys/shm.h>
#include "shared_data.h"
#include<string.h>
#include<stdlib.h>

int main()
{
int segid,pid,mqid;
char *seg_pntr;
int nmbr;

nmbr = rand()%500;

segid = shmget (MEMKEY,SIZE, IPC_CREAT | 0666 ); //Create segment if it does not exist
if( segid < 0) {
  printf("segment Error\n");
  return 0;
}
//Notice the explicit mention of 0666, This means give rw permissions to users,groups and others
seg_pntr = attachSHM();

sprintf(seg_pntr,"%d ",nmbr);
printf("Number written to shared memory is %d\n",nmbr);

mqid = msgget( QUEUEKEY, IPC_CREAT | 0666 );
printf("Created MessageQueue with mqid = %d\n",mqid); //Create the message queue
printf("Starting the dispatcher.c program\n");

system("/bin/bash -c 'cc dispatcher.c'");
system("/bin/bash -c './a.out'"); 
    //Call writer2.c

return (0);
}
