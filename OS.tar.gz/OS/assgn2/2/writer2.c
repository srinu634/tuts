#include<stdio.h>
#include<sys/shm.h>
#include<string.h>
#include "shared_data.h"
#include<fcntl.h> //File control constants
#include<mqueue.h>
#include<stdlib.h>

int main( ) {

long datalength;
int memsegid,mqid;
char *memseg_pntr;
int nmbr;
static struct message m1;
printf("Writer2 has started\n");
mqid = msgget( QUEUEKEY, IPC_CREAT | 0666 );
printf("mqid = %d\n",mqid);
 
//Create a message to send
datalength = sizeof(m1) - sizeof(m1.type);


memsegid = getSegID(); //Get the segment ,a function defined in shared_data.h 
memseg_pntr = attachSHM(); //Attach the shared memory to the virtual memory space, in shared_data.h
sscanf(memseg_pntr,"%d",&nmbr); //Read the number from the SharedMemory
//msgrcv(mqid,&m1,datalength,100,0);

printf("Number scanned from shared memory is %d\n",nmbr);


m1.type = 200;
m1.nmbr = nmbr ;  //Setting message attributes

 msgsnd(mqid,&m1,datalength,0) ;
  printf("Message sent, mqid = %d\n",mqid);

printf("writer2 is exiting\n");
return (0);
}
