#include<stdio.h>
#include<sys/shm.h>
#include<stdlib.h>
#include<string.h>
#include "shared_data.h"
#include<fcntl.h> //File control constants
#include<mqueue.h>

int main(int argc,  char *argv[]) {


printf("In reader2,Number read is %s\n",argv[1]);



return 0;
}
