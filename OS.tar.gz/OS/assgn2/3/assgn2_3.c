/*********** A C program to illustrate MultiThreading in UNIX using pthreads*****/
/*By 	 Srinivas suri (2011A7PS199H)
*	 Arkajyothi Batabyal (2011A7PS167H)
*	 Abhik De (2011C6PS569H) 
*/

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<pthread.h>
#define NUM_THREADS 100 
#define N 100

int mat[N][N];
int sum;

int checkprime(int n) {
int i;

for(i=2;i<n;i++)
	if(n%i==0)
		return 0;
return 1;
}


void *  run_thread(void * param){
void* result;
result=&sum;
int row = atoi(param);
int i;
for(i=0;i<N;i++)
	if( checkprime(mat[row][i])==1)
		sum++;
pthread_exit(0);	
}


int main( ) {

pthread_t threads[NUM_THREADS]; //array of threads
int i,j; //iterators
void *row,*final_result;
int  result;
sum=0;

for(i=0;i<N;i++)
	for(j=0;j<N;j++)
		mat[i][j] = 2 + rand()%(N*N);

for(i=0;i<NUM_THREADS;i++){
	row=&i;
	pthread_create(&threads[i],NULL,&run_thread,row);
}

for(i=0;i<N;i++)
	pthread_join(threads[i],NULL);
printf("Result is %d\n",sum);
return 0;
} //end of main






