/*********** A C program to illustrate forking,Signal Handling in UNIX *****/
/*By 	 Srinivas suri (2011A7PS199H)
*	 Arkajyothi Batabyal (2011A7PS167H)
*	 Abhik De (2011C6PS569H) 
*/


#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<signal.h>

void handler() { 
printf("Sum of odd integers is displayed\n");
exit(0); //Parent exits
}

int main(int arc,char *argv[]){

signal(SIGCHLD,handler); //Defining signal handler

int size=8;
int pid,pid1; //Used in forking process
int arr_num[8]; //Used to store the numbers given during command line
int i;//used for iteration
int sum=0;//sum of the 8 numbers

for(i=0;i<size;i++)
	arr_num[i] = atoi(argv[i+1]);

for(i=0;i<size;i++)
	sum+=arr_num[i];

printf("Sum of the numbers is %d\n",sum);

pid=fork();

if( pid == 0 ){ //Child process
sum=0;
for(i=0;i<size;i++)
	if(arr_num[i]%2==1)
 		sum+=arr_num[i]; //Child calculates sum of odd numbers

printf("Sum of odd numbers is %d\n",sum);

pid1=fork();

if( pid1 ==0 ){
sleep(20); //sleep for 20 seconds
sum=0;
for(i=0;i<size;i++)
	if( arr_num[i]%2==0)
		sum+=arr_num[i];
printf("Sum of even numbers is %d\n",sum);
}
else
{
sleep(1);
exit(0); //Without worrying about child process
}

}// Child  
else{
wait(NULL);
}

return 0;
}  //end of main
