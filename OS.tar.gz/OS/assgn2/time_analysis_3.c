#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<pthread.h>
#include<time.h>
#include<math.h>

int mat[10000][10000];
int sum;
int n,nt,r;

int checkprime(int n) {
int i;
int sqr ;
sqr=sqrt(n);
for(i=2;i<sqr;i++)
	if(n%i==0)
		return 0;
return 1;
}


void *  run_thread(void * param){
void* result;
result=&sum;
int row = atoi(param);
int i;
for(i=0;i<r;i++)
	if( checkprime(mat[row][i])==1)
		sum++;
pthread_exit(0);	
}


int main( ) {


clock_t begin, end;
double time_spent;


pthread_t threads[10000]; //array of threads
int i,j; //iterators
void *row,*final_result;
int  result;


int t=10000;


for(i=0;i<10000;i++)
	for(j=0;j<10000;j++)
		mat[i][j] = 2 + rand()%(100000000);
r=1;
while(t>0){
begin=clock();
printf("Clock started\n");
sum=0;

/*for(i=0;i<r;i++){
	row=&r;
	pthread_create(&threads[i],NULL,&run_thread,row);
}

for(i=0;i<r;i++)
	pthread_join(threads[i],NULL);
*/
/*
for(i=0;i<r;i++)
	for(j=0;j<r;j++)
		if(checkprime(mat[i][j])==1) sum++;
*/
printf("Result is %d\n",sum);
end=clock();
time_spent = (double)(end-begin)/ CLOCKS_PER_SEC;
printf("Time spent is %lf\n",time_spent);
t/=10;r*=10;
}
return 0;
} //end of main






