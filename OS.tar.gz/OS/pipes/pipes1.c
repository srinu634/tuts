/* By Srinivas Suri (2011A7PS199H) 
-> C program Illustrating how two processes communicate with each other using pipes
-> In this example,a parent talks with child using a pipe
-> Pipe is always unidirectional,In our case,parent sends data,child receives data
-> That is,parent writes to  pipe,child reads from the pipe
-> Using dup to close the stdin of the child.
-> Again,Using dup to close the stdout of the parent
-> So that typically, parent printf's to a child and child scanf's from the parent
*/

#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#define SIZE 25

int main() { 
int pid;
int IO[2];   //An array which contains info about input,output
int number=100;

pipe(IO); // Telling the OS that IO is used for piping 

pid=fork();

if(pid==0) {   //Child process 
close(0); //Close the stdin of the child
scanf("%d",&number);
printf("Number scanned is %d\n",number);
close(IO[1]); //Close the write end of the Child
close(IO[0]); //close the read end of the child
}
else
{ //Parent Process
close(1);//close the stdout of the parent
close(IO[0]); //close the read end of the parent

printf("%d",number);
close(IO[1]); //close the write end of the parent
}


return 0;
}
