/* By Srinivas Suri (2011A7PS199H) 
-> C program Illustrating how two processes communicate with each other using pipes
-> In this example,a parent talks with child using a pipe
-> Pipe is always unidirectional,In our case,parent sends data,child receives data
-> That is,parent writes to  pipe,child reads from the pipe
*/

#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#define SIZE 25

int main() { 
int pid;
int IO[2];   //An array which contains info about input,output
char str[SIZE],temp[SIZE];

strcpy(temp,"Welcome");
pipe(IO); // Telling the OS that IO is used for piping 

pid=fork();

if(pid==0) {   //Child process 
close(IO[1]); //Close the write end of the Child
read(IO[0],str,SIZE);
printf("String array that flowed through pipe from parent to child is: %s\n",str);
close(IO[0]); //close the read end of the child
}
else
{ //Parent Process
close(IO[0]); //close the read end of the parent
write(IO[1],temp, strlen(temp)+1);
close(IO[1]); //close the write end of the parent
}


return 0;
}
