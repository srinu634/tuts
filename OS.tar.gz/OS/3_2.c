/*By 	 Srinivas suri (20111A7PS199H)
*	 Arkajyothi Batabyal (2011A7PS167H)
*	 Abhik De (2011C6PS569H) 
*/


 #include <stdio.h>
 #include <unistd.h> 
#include <stdlib.h> 
#include <pthread.h> 
#include <semaphore.h> 
#include<error.h>
#include<time.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>
// The maximum number of customer threads.
 #define MAX_CUSTOMERS 50
 #define MAX_BARBER 3
 #define NUM_CHAIRS 10
 //Function prototypes... 
void *customer(void *num); 
void *barber(void * i); 
void randwait(int secs);
int numChairs,cust;

typedef struct {
  sem_t barberChair;
  sem_t waitingRoom;
  sem_t seatBelt;
  sem_t custAvail;
  sem_t barber;
  sem_t leave;
  int paid;
  int time;
  sem_t dormant;
} queue_t;
queue_t q[3];


sem_t barberPillow;
 // Define the semaphores. 
// waitingRoom Limits the # of customers allowed 
// to enter the waiting room at one time.
 /*sem_t waitingRoom;
 // barberChair ensures mutually exclusive access to // the barber chair. 
sem_t barberChair;
sem_t leave;
sem_t seatBelt;
sem_t custAvail;
 // barberPillow is used to allow the barber to sleep 
// until a customer arrives.
 sem_t barberPillow; 
// seatBelt is used to make the customer to wait until 
// the barber is done cutting his/her hair.
 //sem_t 
*/
// Flag to stop the barber thread when all customers 
// have been serviced. 
int allDone = 0;
 int main(int argc, char *argv[])
 {
 pthread_t btid[3];
 pthread_t tid[MAX_CUSTOMERS];
 long RandSeed; 
int i, numCustomers; 
int Number[MAX_CUSTOMERS];
 // Check to make sure there are the right number of // command line arguments.
 if (argc != 3) 
{
 printf("Use: SleepBarber <Num Customers> <rand seed>\n");
 exit(-1);
 }
 // Get the command line arguments and convert them
 // into integers. 
numCustomers = atoi(argv[1]);
 //numChairs = atoi(argv[2]); 
RandSeed = atol(argv[2]); 
// Make sure the number of threads is less than the number of
 // customers we can support.
 if (numCustomers > MAX_CUSTOMERS) 
{
 printf("The maximum number of Customers is %d.\n", MAX_CUSTOMERS);
 exit(-1);
 }
 printf("\nSleepBarber.c\n\n");
 printf("A solution to the sleeping barber problem using semaphores.\n");
 // Initialize the random number generator with a new seed. srand48(RandSeed);
 // Initialize the numbers array. 
for (i=0; i<MAX_CUSTOMERS; i++) { Number[i] = i; } 
// Initialize the semaphores with initial values... 
for (i=0; i<MAX_BARBER; i++) { 
sem_init(&(q[i].waitingRoom), 0, NUM_CHAIRS);
 sem_init(&(q[i].barberChair), 0, 0);
 sem_init(&(q[i].leave), 0, 0);	
 sem_init(&(q[i].barber), 0, 1);
sem_init(&(q[i].custAvail), 0, 0);
 sem_init(&(q[i].seatBelt), 0, 0);
 sem_init(&(q[i].dormant), 0, 0);
q[i].paid=0;
}
q[0].time=5;
q[1].time=10;
q[2].time=5;
cust;
sem_init(&barberPillow, 0, 1);
 // Create the barbers. 
int l,m,n;
l=0; m=1; n=2; 
pthread_create(&btid[0], NULL, barber, (void *)&l);
pthread_create(&btid[1], NULL, barber, (void *)&m);
pthread_create(&btid[2], NULL, barber, (void *)&n);
 // Create the customers.
 for (i=0; i<numCustomers; i++) 
{
 pthread_create(&tid[i], NULL, customer, (void *)&Number[i]); 
}
 // Join each of the threads to wait for them to finish. 
for (i=0; i<numCustomers; i++) 
{
 pthread_join(tid[i],NULL);
 }
 // When all of the customers are finished, kill the // barber thread. 
printf("Customers are finished");
allDone = 1;
// Wake the barber so he will exit.
for (i=0; i<MAX_BARBER; i++) 
sem_post(&(q[i].dormant));
sem_post(&barberPillow); 

sleep(2);
for (i=0; i<MAX_BARBER; i++)
pthread_kill(btid[i], 0); 
/*for (i=0; i<MAX_BARBER; i++) 
pthread_join(btid[i],NULL);*/

for (i=0; i<MAX_BARBER; i++)
printf("The barber % d is going home for the day with salary %d.\n",i,q[i].paid);
 }

/////////////////////////////////////////////////////////////////////////////////////Customer
 void *customer(void *number) 
{ int bp,wt,s;
 int num = *(int *)number;
 

// Leave for the shop and take some random amount of 
// time to arrive. 
printf("Customer %d leaving for barber shop.\n", num); 
randwait(5);
if(num==5)
{sleep(80);
}
 printf("Customer %d arrived at barber shop.\n", num);

int k=(int) ((drand48() * 17) + 1);
k=k%3;
sem_getvalue(&(q[k].waitingRoom), &wt);
if(wt==0)
{printf("Customer %d leaving barber shop due to lack of space.\n", num);
cust++;
pthread_exit(0);
} 

 // Wait for space to open up in the waiting room... 
L1:sem_wait(&(q[k].waitingRoom)); 
sem_post(&(q[k].dormant));


printf("Customer %d entering waiting room for barber %d.\n", num,k); 
// Wait for the barber chair to become free. 
int m;
struct timespec ts;
if (clock_gettime(CLOCK_REALTIME, &ts) == -1) {
        perror("clock_gettime");
        exit(EXIT_FAILURE);
    }
    ts.tv_sec += 20;
while (((m = sem_timedwait(&(q[k].barberChair), &ts)) == -1) && (errno == EINTR))
        continue;  
int b,cnt,l,a,h;
cnt=0;
   if (m == -1) {
        if (errno == ETIMEDOUT)
            {
	    printf("sem_timedwait() timed out\n");
            sem_post(&(q[k].waitingRoom));
            
	    for (h=0; h<MAX_BARBER; h++) 
		{
			if(h==k)
			continue;
			else 
			{  
				if(cnt==0)
		   		{
					sem_getvalue(&(q[h].waitingRoom),&b);
					l=h;
		  		 }
		   		sem_getvalue(&(q[h].waitingRoom),&a);
		   		if(a>b) l=h;
		    	
			}	
		}
		printf("^^^^^^^^^^^^^^^^^^^^^^^^^^^^Customer %d is shifted from barber %d to barber %d\n",num,k,l);
		k=l;
		goto L1;	
			
	     
	       
        }else
            perror("sem_timedwait");
    } else
        printf("sem_timedwait() succeeded\n");

// The chair is free so give up your spot in the 
// waiting room. 
sem_post(&(q[k].waitingRoom)); 
printf("Customer %d leaving waiting room.\n", num);
sem_getvalue(&barberPillow, &bp);

//if((sem_wait(&barberPillow))==0);
if(bp>=1)
{
// Wake up the barber...
 printf("Customer %d waking up the barbers.\n", num);
 sem_wait(&barberPillow);
}

 
sem_post(&(q[k].custAvail));
// Wait for the barber to finish cutting your hair.
sem_wait(&(q[k].seatBelt)); 

printf("Customer %d is getting haircut from barber %d.\n", num,k);
// Give up the chair. 
sem_wait(&(q[k].leave)); 
printf("Customer %d leaving barber shop.\n", num);

pthread_exit(0);
 }


/////////////////////////////////////////////////////////////////////////////////////barber
 void *barber(void *number) 
{ int wt[3],bt[3],bc,j;
int i = *(int *)number;
 // While there are still customers to be serviced... 
// Our barber is omnicient and can tell if there are // customers still on the way to his shop.
printf("The barber %d is sleeping\n",i);
sem_post(&(q[i].barberChair)); 
sem_wait(&(q[i].dormant));
sem_getvalue(&barberPillow, &bc);
printf("barberPillow is %d\n",bc);
printf("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& Barber %d started \n",i);
 while (!allDone)
 {
  	// Skip this stuff at the end... 
	/*if (!allDone)
 	{  	sem_getvalue(&seatBelt, &bc);
		if(bc==0)
			{*/	printf("hello\n");
				sem_wait(&(q[i].custAvail));
				sem_wait(&(q[i].barber));
				printf("///////The barber %d is cutting hair////////////////////%d\n", i,i);
				sem_post(&(q[i].seatBelt));
				q[i].paid++;
 				sleep(q[i].time);
				
				
 				printf("The barber %d has finished cutting hair.\n",i); 
				// Release the customer when done cutting... 
				sem_post(&(q[i].barber));
				sem_post(&(q[i].barberChair));
				sem_post(&(q[i].leave));
			//}
			for (j=0; j<MAX_BARBER; j++) {
			sem_getvalue(&(q[j].waitingRoom), &wt[j]);
			sem_getvalue(&(q[j].barberChair), &bt[j]);
			}
			if(wt[0]>=NUM_CHAIRS && wt[1]>=NUM_CHAIRS && wt[2]>=NUM_CHAIRS && bt[0]==1 && bt[1]==1 && bt[2]==1)
				{	printf("Before Sleeping of Barber %d he has Earned %d\n",i,q[i].paid);
					printf("No waitng customers\n");
					printf("All barbers are sleeping\n");
					sem_post(&barberPillow);
					
					sem_getvalue(&barberPillow, &bc);
					printf("barberPillow is %d\n",bc);
										
		 		}
			else printf("***********************Waitng customers for barber %d  are %d\n",i,NUM_CHAIRS-wt[i]);
			 
	}
		
	
	 
 
pthread_exit(0); 
 }



 void randwait(int secs)
 {
 int len;
 // Generate a random number... 
len = (int) ((drand48() * secs) + 1); 
sleep(len);
 }
