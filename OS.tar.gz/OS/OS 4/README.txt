Sir(s),


For Virtual Machine:-

Memory - 512MB RAM
Total Space - 6GB ( actual hard disk - 25GB )


For Flash Drive :-

Memory - 512MB RAM
Total SPace - 6GB ( actual space in flash drive - 16GB )
