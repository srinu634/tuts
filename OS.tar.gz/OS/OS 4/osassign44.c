#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>


struct node{
	char ch[1048576];
};


int main()
{
	char c;
	int i,j;
	struct node *n[4124];
	clock_t t1,t2;

	for(i=0;i<4124;i++)
	{
		n[i] = (struct node *)malloc(sizeof(struct node));
	}

	srand(time(NULL));

	t1 = clock();
	
	for(i=0;i<10000;i++)
	{
		n[rand()%4124]->ch[rand()%1048576] = 'a';          //(int)rand()%4000  (int)rand()%1000000
	}
	

	t2 = clock();

	for(i=0;i<4124;i++)
	{
		free(n[i]);
	}	
	
	printf("write time for 10000 iterations = %lf\n",((double)(t2-t1))/(CLOCKS_PER_SEC));

	return 0;
}
