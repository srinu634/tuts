#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>


struct node{
	char ch[1048576];
};


int main()
{
	char c;
	int i,j;
	struct node *n[4124];
	clock_t t1,t2;

	for(i=0;i<4124;i++)
	{
		n[i] = (struct node *)malloc(sizeof(struct node));
	}

	srand(time(NULL));

	t1 = clock();
	
	for(i=0;i<1000000;i++)
	{
		c = n[(int)rand()%4124]->ch[rand()%1000000];          //(int)rand()%4000  (int)rand()%1000000
	}
	

	t2 = clock();

	for(i=0;i<4124;i++)
	{
		free(n[i]);
	}	
	
	printf("read time = %f\n",((double)(t2-t1)/CLOCKS_PER_SEC));

	return 0;
}
