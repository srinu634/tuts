#include<stdio.h>
#include<stdlib.h>
#include<time.h>

struct node{
	char ch[1048576];
};

int main()
{
	struct node *n[4124];
	int i,j;
	clock_t t1,t2,t3;

	t1 = clock();	
	
	for(i=0;i<4124;i++){
		n[i] = (struct node *)malloc(sizeof(struct node));
	}

	t2 = clock();

	for(i=0;i<4124;i++){
		free(n[i]);
	}

	t3 = clock();
	
printf("alloc = %lf      dealloc = %lf\n",(double)(t2-t1)/(CLOCKS_PER_SEC*4124),(double)(t3-t2)/(CLOCKS_PER_SEC*4124));
	//printf("alloc = %lf      dealloc = %lf\n",(double)((t2-t1)/(CLOCKS_PER_SEC)),(double)((t3-t2)/(CLOCKS_PER_SEC)));

	return 0;
}
