/*********** A C program to illustrate DeadLock,Starvation in UNIX using pthreads*****/
/*By 	 Srinivas suri (201i1A7PS199H)
*	 Arkajyothi Batabyal (2011A7PS167H)
*	 Abhik De (2011C6PS569H) 
*/

/* 
   Real Time Scheduling used to increase Thread Priority:  FIFO
   Starvation Detect if TLE 10 seconds
   FileQueue in a Controlled through Mutex
   File sharing controlled through Locks.
   M Threads, N Files with M > N
   Whenever there is a deadlock, one of the thread in the deadlock is killed 
*/

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<pthread.h>
#include<time.h>
#include<sched.h>


#define true 1
#define false 0
#define N 10
#define M 20 //20 Threads  

pthread_t threads[M]; //Array of threads
pthread_t detect; //Thread to detect a deadlock
pthread_t print_thread; //To print the table
pthread_mutex_t lock[N]; //For each file[1..N]
pthread_mutex_t qlock,curr_lock; //To lock the Queue

int queue[N][M]; //N Files, M Threads 
int graph[M][M]; //waitforgraph
int visited[M]; //For GraphSearch
int current[N]; //Which thread holds the file
clock_t begin[M],t;
int exit_flag[M] ;

void writetofile(int findex,int tnmbr,int t){ 
FILE *fp;
char filename[20],nmbr[10];
strcpy(filename,"file[");
        sprintf(nmbr,"%d",findex);
        strcat(filename,nmbr); 
        strcat(filename,"].txt");
        fp = fopen(filename,"a");

fprintf(fp,"%d %d\n",tnmbr,t);//ThreadNumber TimeStamp
	fclose(fp);
}//end of writetofile


void *printTable( ) {  
int i,j,k,interval;
double time_spent;

while(1){ 
printf("FileNo. \tCurrent \tIn Queue\n");
pthread_mutex_lock(&qlock);
pthread_mutex_lock(&curr_lock);
	for(i=0;i<N;i++){ 
	
		printf("%d\t\t%d\t\t",i,current[i]); 
	
		for(j=0;j<M;j++) 
			if( queue[i][j] == 1 ) { 
			double time_spent;time_spent = (double)(begin[j])/CLOCKS_PER_SEC; 
				printf("%d(%.2lf) ",j,time_spent); }
	printf("\n");

pthread_mutex_unlock(&curr_lock);
pthread_mutex_unlock(&qlock);
}
sleep(2);
}
}//print table

void increase_priority (int tno)  { //ThreadNumber 
struct sched_param params;  // We'll set the priority to the maximum.
int policy;

params.sched_priority = sched_get_priority_max(SCHED_FIFO);
pthread_setschedparam(threads[tno], SCHED_FIFO, &params);

printf("ThreadNo: %d Thread Priority is set to %d\n",tno,params.sched_priority); 
}

void normal_priority (int tno)  { //ThreadNumber 
struct sched_param params;  // We'll set the priority to the maximum.
int policy;

params.sched_priority = sched_get_priority_max(SCHED_OTHER);
pthread_setschedparam(threads[tno], SCHED_OTHER, &params);

//printf("ThreadNo: %d Thread Priority is set to %d\n",tno,params.sched_priority);
}


void* run_thread(void * thrd_nmbr ) {
int findex ,i,j,k;
char str[200],nmbr[200]; 
clock_t diff;
int *value;
value = (int* )thrd_nmbr;

while(1) {
findex =  (rand() )%N ; //For better Randomized Values
begin[*value] = clock();
int add_flag,time_flag;
add_flag = 0;
time_flag = 0;


while( pthread_mutex_trylock( &lock[findex] ) != 0)    //We din't get the lock 
{   

if( add_flag == 0) //In the while loop for the 1st time
	{
	add_flag = 1; //added to the queue
pthread_mutex_lock(&qlock);	
	queue[findex][*value] = 1; //Add to the wait queue
        
pthread_mutex_unlock(&qlock);	
begin[i] = clock();
} 

double time_spent; 
time_spent = (double) (begin[i] - t)/CLOCKS_PER_SEC;
if( time_flag == 0 && time_spent > 60 ) {
	increase_priority( *value); //Increase the Priority of the thread 
	time_flag = 1;
}

}  //Busy- Waiting Included

//Entered the Critical Section
normal_priority(*value );

pthread_mutex_lock( &qlock);
	queue[findex][*value] = -1; //Remove from the wait Queue
		graph[*value][current[findex ]] = 1;
pthread_mutex_unlock( & qlock);

pthread_mutex_lock(&curr_lock);
	current[findex] = *value ; //Update that this thread locked f[nmbr].txt
pthread_mutex_unlock(&curr_lock);
int ttl =  2 + rand()%5  ; 

while (  ttl-- ) 
	{
	writetofile(findex, *value,ttl);
	sleep(1);
	}	

pthread_mutex_lock(&curr_lock);
	graph[*value][current[findex]] = -1;
	current[*value] = -1 ;
pthread_mutex_unlock(&curr_lock);

pthread_mutex_unlock( &lock[findex] ); //Unlock it
if ( exit_flag[*value] == 1)
	pthread_exit(0);

}

}//end of run_thread


void dfs(int root) { 
int i,j;
if (exit_flag[root] ==1 ) //A thread that is terminated already
	return;

for(i=0;i<M;i++){
	if( root!= i && graph[root][i] == 1 && visited[i] == false ) {
	visited[i] = true;
	dfs(i);
	}
	else if( graph[root][i] == 0)
	continue;
	else if (  root != i && (graph[root][i] == 1) && visited[i] == true && graph[i][root]!=0 ){
	printf("Terminating Thread No. %d\n", root);	
	exit_flag[root] = 1;
	}
}

}//dfs

void *run_detect( ) { return ;
int i,j;
while(true){
sleep(10);
printf("IN DEADLOCK ROUTINE\n");


pthread_mutex_lock(&qlock);
pthread_mutex_lock(&curr_lock);
		
	for(i=0;i<M;i++)
		visited[i] = false;
	
	for(i=0;i<M;i++){
	if( visited[i] == false ){
	visited[i] = true;
	dfs(i); //Run dfs starting from node i.
	}
	}
pthread_mutex_unlock(&curr_lock);
pthread_mutex_unlock(&qlock);
}
}




void *createFiles(int n) { 
int i,i1;
char filename[20],nmbr[10];
FILE *fp;

for(i=0;i<n;i++) { 
	strcpy(filename,"file[");
	sprintf(nmbr,"%d",i);
	strcat(filename,nmbr); //How to convert from int to string?
	strcat(filename,"].txt");
	fp = fopen(filename,"w+");
	fclose(fp);	
}

}



int main( ) {
int i,j,k,a[M]; 


/******INITIALISE ALL THE REQUIRED VARIABLES********/
createFiles(N); // To create N Files.
for(i=0;i<M;i++) {
	a[i] = i;
	exit_flag[i] = 0;	
}

srand( time(NULL) );
t = clock( );


for(i=0;i<M;i++)
for(j=0;j<M;j++)
graph[i][j] = -1;

for(i=0;i<N;i++)
	pthread_mutex_init(&lock[i],NULL);
	pthread_mutex_init(&qlock,NULL);
	pthread_mutex_init(&curr_lock,NULL);

for(i=0;i<M;i++)
	for(j=0;j<N;j++)
		queue[i][j] = -1; //Initially all are empty


for(i=0;i<M;i++) 
	pthread_create(&threads[i],NULL,&run_thread,&a[i]); //Thread,Attr,Routine,Args
	
	pthread_create(&detect,NULL,&run_detect,NULL);
	pthread_create(&print_thread,NULL,&printTable,NULL);	
	
for(i=0;i<M;i++)
	pthread_join(threads[i],NULL );
return 0;
} //end of main






