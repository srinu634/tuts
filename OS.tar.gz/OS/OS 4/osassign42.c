#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>


struct node{
	char ch[1048576];
};


int main()
{
	char c;
	int i,j;
	struct node *n[10];
	clock_t t1,t2;

srand(time(NULL));	
	
	for(i=0;i<10;i++)
	{
		n[i] = (struct node *)malloc(sizeof(struct node));
	}

	t1 = clock();

	for(i=0;i<1000000;i++)
	{
		c =  n[rand()%10]->ch[rand()%1048576];
	}
	

	t2 = clock();
	for(i=0;i<10;i++)
	{
		free(n[i]);
	}
	printf("access time = %lf\n",((double)(t2-t1))/(CLOCKS_PER_SEC));

	return 0;
}
